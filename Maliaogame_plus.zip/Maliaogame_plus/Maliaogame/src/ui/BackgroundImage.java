package ui;
import java.awt.Image;
import javax.swing.ImageIcon;

public class BackgroundImage {
	public boolean endflag = false;
	public int x=0,y=0;
	public int ox=0,oy=0;
	public Image img=new ImageIcon("image/startBack.jpg").getImage();

}
