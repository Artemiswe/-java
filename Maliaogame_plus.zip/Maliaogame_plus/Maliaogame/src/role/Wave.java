package role;
import java.awt.Image;
//������
public class Wave extends Enemy {
public Wave(int x, int y, int width, int height, Image img) {
		super(x, y, width, height, img);
		// TODO Auto-generated constructor stub
	}
}