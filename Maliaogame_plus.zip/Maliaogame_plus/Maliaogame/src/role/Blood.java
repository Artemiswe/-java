package role;
import java.awt.Image;

//Ѫ����
public class Blood extends Enemy{
	public Blood(int x, int y, int width, int height, Image img) {
		super(x, y, width, height, img);
		// TODO Auto-generated constructor stub
	}
}
