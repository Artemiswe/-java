
package role;
import java.awt.Image;

public class Castle extends Enemy {
    public Castle(int x, int y, int width, int height, Image img) {
        super(x, y, width, height, img);
    }
}