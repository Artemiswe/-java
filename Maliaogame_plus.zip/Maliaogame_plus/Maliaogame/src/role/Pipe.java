package role;
import java.awt.Image;
//ˮ����
public class Pipe extends Enemy {
	public Pipe(int x, int y, int width, int height, Image img) {
		super(x, y, width, height, img);
	}
}
