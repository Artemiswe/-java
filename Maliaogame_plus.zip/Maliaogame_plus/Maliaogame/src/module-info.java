module maLiAoGame {
	requires java.desktop;
    requires java.sql;
}
